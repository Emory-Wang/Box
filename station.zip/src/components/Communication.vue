<template>
	<p> 通信指挥</p>
</template>

<script>
</script>

<style>
</style>
