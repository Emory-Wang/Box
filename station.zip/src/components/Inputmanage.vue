<template>
	<p> 输入管理</p>
</template>

<script>
</script>

<style>
</style>
